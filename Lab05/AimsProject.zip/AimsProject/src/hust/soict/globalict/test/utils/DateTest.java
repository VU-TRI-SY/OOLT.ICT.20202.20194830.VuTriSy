package hust.soict.globalict.test.utils;
public class DateTest {
	public static void main(String []args) {
		System.out.println("a");
	}
}
